import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class BookHelper {
    int choice;
    String fullname,username, password, confirmPassword;

    ArrayList<Student> studentList=new ArrayList<>();
    ArrayList<Admin> adminList=new ArrayList<>();
    Scanner sc=new Scanner(System.in);



}
