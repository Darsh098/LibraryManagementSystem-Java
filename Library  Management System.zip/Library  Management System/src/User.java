interface User {
    public static final String fullname=null;
    public static final String username=null;
    public static final String password=null;
 // Getter method to return the full name of the user
    public String getFullname();

    // Setter method to set the full name of the user
    public void setFullname(String fullname);

    // Getter method to return the username of the user
    public String getUsername();

    // Setter method to set the username of the user
    public void setUsername(String username);
    // Getter method to return the password of the user
    public String getPassword();

    // Setter method to set the password of the user
    public void setPassword(String password);
}
